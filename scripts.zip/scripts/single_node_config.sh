for ARGUMENT in "$@"
do
    KEY=$(echo $ARGUMENT | cut -f1 -d=)
    VALUE=$(echo $ARGUMENT | cut -f2 -d=)   
    
    case "$KEY" in
            CT_ID) CT_ID=${VALUE} ;;
            PW)    PW=${VALUE} ;;     
            *)   
    esac  
done

############## SSHD CONFIG ############

echo -e "$PW\n$PW" | docker exec -i $CT_ID passwd
docker exec $CT_ID sed -i "s/PermitRootLogin prohibit-password/PermitRootLogin yes/g" /etc/ssh/sshd_config
docker exec $CT_ID /etc/init.d/ssh restart

############## JUPYTER CONFIG ############

JUPYTER_CONFIG_FILE='/root/.jupyter/jupyter_notebook_config.py'
docker exec $CT_ID rm -rf $JUPYTER_CONFIG_FILE
docker exec $CT_ID jupyter notebook --generate-config

docker exec $CT_ID sed -i -e "s/#c.NotebookApp.ip = 'localhost'/c.NotebookApp.ip = '0.0.0.0'/g" $JUPYTER_CONFIG_FILE
docker exec $CT_ID sed -i -e "s/#c.NotebookApp.open_browser = True/c.NotebookApp.open_browser = False/g" $JUPYTER_CONFIG_FILE
docker exec $CT_ID sed -i -e "s/#c.NotebookApp.allow_root = False/c.NotebookApp.allow_root = True/g" $JUPYTER_CONFIG_FILE

docker exec $CT_ID sed -i -e "s/#c.NotebookApp.password = ''/from notebook.auth import passwd; \nc.NotebookApp.password = passwd('$PW')/g" $JUPYTER_CONFIG_FILE
docker exec $CT_ID sed -i -e "s/#c.NotebookApp.password = u''/from notebook.auth import passwd; \nc.NotebookApp.password = passwd('$PW')/g" $JUPYTER_CONFIG_FILE
docker exec $CT_ID sed -i -e "s/('1')/('$PW')/g" $JUPYTER_CONFIG_FILE

